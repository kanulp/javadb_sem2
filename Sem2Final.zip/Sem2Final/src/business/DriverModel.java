package business;

public class DriverModel {
	
	private int id;
	private String name;
	private String password;
	private String email;
	private String phone;
	private int age;
	private String address;
	private String licenseNumber;
	private String carModel;
	private String carNumberPlate;
	private int experience;
	
	public DriverModel() {
		
	}
	
	public DriverModel(int id, String name, String password, String email, String phone, int age, String address,
			String licenseNumber, String carModel, String carNumberPkate, int experience) {
		this.id = id;
		this.name = name;
		this.password = password;
		this.email = email;
		this.phone = phone;
		this.age = age;
		this.address = address;
		this.licenseNumber = licenseNumber;
		this.carModel = carModel;
		this.carNumberPlate = carNumberPkate;
		this.experience = experience;
	}
	public DriverModel(String name, String password, String email, String phone, int age, String address,
			String licenseNumber, String carModel, String carNumberPkate, int experience) {
		this.name = name;
		this.password = password;
		this.email = email;
		this.phone = phone;
		this.age = age;
		this.address = address;
		this.licenseNumber = licenseNumber;
		this.carModel = carModel;
		this.carNumberPlate = carNumberPkate;
		this.experience = experience;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLicenseNumber() {
		return licenseNumber;
	}
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public String getCarNumberPlate() {
		return carNumberPlate;
	}
	public void setCarNumberPlate(String carNumberPlate) {
		this.carNumberPlate = carNumberPlate;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	
	

}

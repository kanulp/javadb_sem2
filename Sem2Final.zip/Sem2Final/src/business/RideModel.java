package business;

public class RideModel {
    private int id;
    private String source;
    private String destination;
    private Double price;
    private String startTime;
    private int travelTime;
    private int driverId;
    private int completed;

    public RideModel(){

    }
    
    

    public RideModel(int id, String source, String destination, Double price, String startTime, int travelTime,
			int driverId, int completed) {
		super();
		this.id = id;
		this.source = source;
		this.destination = destination;
		this.price = price;
		this.startTime = startTime;
		this.travelTime = travelTime;
		this.driverId = driverId;
		this.completed = completed;
	}

	public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource() {
        return this.source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return this.destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Double getPrice() {
        return this.price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getStartTime() {
        return this.startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public int getTravelTime() {
        return this.travelTime;
    }

    public void setTravelTime(int travelTime) {
        this.travelTime = travelTime;
    }

    public int getDriverId() {
        return this.driverId;
    }

    public void setDriverId(int driverId) {
        this.driverId = driverId;
    }

    public int getCompleted() {
        return this.completed;
    }

    public void setCompleted(int completed) {
        this.completed = completed;
    }


}
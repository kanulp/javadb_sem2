package data;

import java.io.*;
import java.util.ArrayList;
import business.CustomerModel;

public class PersonDAOText implements PersonDAO {
	private File personFile = null;

	public PersonDAOText() {
		personFile = new File(PersonConstants.FILENAME_TEXT);
	}

	private void checkFile() throws IOException {
		if (!personFile.exists())
			personFile.createNewFile();
	}

	private boolean savePersons(ArrayList<CustomerModel> persons) {
		PrintWriter out = null;
		try {
			this.checkFile();
			out = new PrintWriter(new BufferedWriter(new FileWriter(personFile)));
			for (CustomerModel p : persons) {
				
				out.print(p.getId() + FIELD_SEP);
				out.print(p.getName() + FIELD_SEP);
				out.print(p.getPassword() + FIELD_SEP);
				out.print(p.getEmail() + FIELD_SEP);
				out.print(p.getPhone() + FIELD_SEP);
				out.print(p.getAge() + FIELD_SEP);
				out.print(p.getAddress() + FIELD_SEP);
				out.println(p.getCoupon()==""?"no":p.getCoupon());
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return false;
		} finally {
			this.close(out);
		}
		return true;
	}

	private void close(Closeable stream) {
		try {
			if(stream!=null)
				stream.close();
		}
		catch(IOException io)
		{
			io.printStackTrace();
		}
		
	}

	@Override
	public CustomerModel getPerson(String firstName) {
		ArrayList<CustomerModel> persons = this.getPersons();
		for (CustomerModel p : persons) {
			if (p.getName().equalsIgnoreCase(firstName))
				return p;
		}
		return null;
	}

	@Override
	public ArrayList<CustomerModel> getPersons() {

		BufferedReader in = null;
		try {
			this.checkFile();
			in = new BufferedReader(new FileReader(personFile));
			ArrayList<CustomerModel> persons = new ArrayList<CustomerModel>();
			String line = in.readLine();
			while (line != null) {
				String[] columns = line.split(FIELD_SEP);
				
				int id = Integer.parseInt(columns[0]);
				
				String Username = columns[1];
				String Password = columns[2];
				String Email = columns[3];
				String Phone = columns[4];
				int age = Integer.parseInt(columns[5]);
				
				String Address = columns[6];
				
				String coupon = columns[7];
				
				CustomerModel customerModel = new CustomerModel(id,Username,Password,Email,Phone,age,Address,coupon);

				persons.add(customerModel);
				line = in.readLine();
			}
			return persons;
		}

		catch (IOException io) {
			io.printStackTrace();
			return null;
		} finally {
			this.close(in);
		}

	}

	@Override
	public boolean addPerson(CustomerModel person) {

		ArrayList<CustomerModel> persons = this.getPersons();
		persons.add(person);
		return this.savePersons(persons);
	}
}

package data;

public interface PersonConstants {
	
	String FILENAME_TEXT="customer.txt";
	String FILENAME_BIN="persons.dat";
	String FILENAME_BIN_FIXED="personFixed.dat";
	
	String FIELD_SEP="\t";
	
	int FIRST_NAME_SIZE=25;
	int LAST_NAME_SIZE=25;
	int ID=4;
	int GENDER_SIZE=6;


	
    int RECORD_SIZE=ID*2 + FIRST_NAME_SIZE*6;
}

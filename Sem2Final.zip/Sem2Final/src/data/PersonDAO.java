package data;

public interface PersonDAO extends PersonReader,PersonWriter,PersonConstants {

}

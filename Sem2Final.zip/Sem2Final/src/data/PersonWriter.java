package data;

public interface PersonWriter {

	boolean addPerson(business.CustomerModel customerModel);
}

package data;

public class DAOFactory {
public static PersonDAO getPersonDAO() {
	PersonDAO pDAO=new PersonDAOText();
	return pDAO;
}
}

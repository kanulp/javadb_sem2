package data;

import java.util.*;

public interface  PersonReader 
{
	business.CustomerModel getPerson(String firstName);
	ArrayList<business.CustomerModel> getPersons();

}

package data;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import business.CustomerModel;
import business.DriverModel;
import business.RideModel;

public class DBAccess {
	protected Connection conn=null;
	protected ResultSet rs=null;
	protected Statement stm=null;
	
	public DBAccess() throws SQLException,ClassNotFoundException{
	this.connect();
	}
	
	protected void connect() throws SQLException,ClassNotFoundException{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		final String url ="jdbc:oracle:thin:@CALVIN.HUMBER.CA:1521:GROK";
		final String username = "N01349164";
		final String password = "oracle";
		conn = DriverManager.getConnection(url,username,password);
//		String sql = "Select * From Programs";
//		stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
//		rs = stm.executeQuery(sql);
	}
	public void disconnect() throws SQLException{
		if (!rs.isClosed()) {
			rs.close();
			conn.close();
		}
	}
	
//	public void refresh() throws SQLException{
//		String sql = "Select * From Programs";
//		stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
//		rs = stm.executeQuery(sql);
//		rs.first();
//	}
	
//	public int addProgram(DriverModel program) throws SQLException{
//		int count=0;
//		String query = "Insert into programs values (?, ?, ?, ?)"; 
//		PreparedStatement preparedStmt = conn.prepareStatement(query);
//	     preparedStmt.setString(1, program.getpID());
//	     preparedStmt.setString(2, program.getpName());
//	     preparedStmt.setString(3, program.getpSeats());
//	     preparedStmt.setString(4, program.getpSemesters());
//	     preparedStmt.execute();
//	     this.refresh();
//		return count;
//	}
	public int registerDriver(final DriverModel driverModel) throws SQLException{
		final int count=0;
		final String query = "Insert into tbl_cab_driver(id,name,password,email,phonenumber,age,address,licensenumber,carmodel,carnumberplate,experience) values (?,?,?,?,?,?,?,?,?,?,?)"; 
		final PreparedStatement preparedStmt = conn.prepareStatement(query);
		
		preparedStmt.setInt(1, driverModel.getId());
		preparedStmt.setString(2, driverModel.getName());
		preparedStmt.setString(3, driverModel.getPassword());
	     preparedStmt.setString(4, driverModel.getEmail());
	     preparedStmt.setString(5, driverModel.getPhone());
	     preparedStmt.setInt(6, driverModel.getAge());
	     preparedStmt.setString(7, driverModel.getAddress());
	     preparedStmt.setString(8, driverModel.getLicenseNumber());
	     preparedStmt.setString(9, driverModel.getCarModel());
	     preparedStmt.setString(10, driverModel.getCarNumberPlate());
	     preparedStmt.setInt(11, driverModel.getExperience());
	     preparedStmt.execute();
	     //this.refresh();
		return count;
	}
	public int registerCustomer(final CustomerModel customerModel) throws SQLException{
		final int count=0;
		final String query = "Insert into tbl_cab_customer values (?,?,?,?,?,?,?,?)"; 
		final PreparedStatement preparedStmt = conn.prepareStatement(query);
		
		preparedStmt.setInt(1, customerModel.getId());
		preparedStmt.setString(2, customerModel.getName());
		preparedStmt.setString(3, customerModel.getPassword());
	     preparedStmt.setString(4, customerModel.getEmail());
	     preparedStmt.setString(5, customerModel.getPhone());
	     preparedStmt.setInt(6, customerModel.getAge());
	     preparedStmt.setString(7, customerModel.getAddress());
	     preparedStmt.setString(8, customerModel.getCoupon());
	     preparedStmt.execute();
	     //this.refresh();
		return count;
	}
	public int createRide(final RideModel rideModel) throws SQLException{
		final int count=0;
		final String query = "Insert into tbl_cab_rides values (?,?,?,?,?,?,?,?)"; 
		final PreparedStatement preparedStmt = conn.prepareStatement(query);
		
		preparedStmt.setInt(1, rideModel.getId());
		preparedStmt.setString(2, rideModel.getSource());
		preparedStmt.setString(3, rideModel.getStartTime());
	     preparedStmt.setDouble(4, rideModel.getPrice());
	     preparedStmt.setString(5, rideModel.getDestination());
	     preparedStmt.setInt(6, rideModel.getDriverId());
	     preparedStmt.setInt(7, rideModel.getCompleted());
	     preparedStmt.setInt(8, rideModel.getTravelTime());
	     preparedStmt.execute();
	     //this.refresh();
		return count;
	}
	
	public DriverModel checkLoginDriver(final String email,final String password) 
	{
		DriverModel driverModel = null;
		
		final String sql = "Select * From tbl_cab_driver where email = '"+email+"' and password = '"+password+"' ";
		System.out.println(sql);
		try {
		stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		rs = stm.executeQuery(sql);
		while(rs.next()) {
			driverModel=new DriverModel();
			driverModel.setId(rs.getInt("id"));
			driverModel.setName(rs.getString("name"));
			driverModel.setPassword(rs.getString("password"));
			driverModel.setPhone(rs.getString("phonenumber"));
			driverModel.setAge(rs.getInt("age"));
			driverModel.setAddress(rs.getString("address"));
			driverModel.setLicenseNumber(rs.getString("licenseNumber"));
			driverModel.setCarModel(rs.getString("carModel"));
			driverModel.setCarNumberPlate(rs.getString("carNumberPlate"));
			driverModel.setExperience(rs.getInt("experience"));
		}
		} catch (final SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return driverModel;
		
	}	
	public CustomerModel checkLoginCustomer(final String email,final String password) 
	{
		CustomerModel customerModel = null;
		
		final String sql = "Select * From tbl_cab_customer where email = '"+email+"' and password = '"+password+"' ";
		System.out.println(sql);
		try {
		stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		rs = stm.executeQuery(sql);
		while(rs.next()) {
			customerModel=new CustomerModel();
			customerModel.setId(rs.getInt("id"));
			customerModel.setName(rs.getString("name"));
			customerModel.setPassword(rs.getString("password"));
			customerModel.setPhone(rs.getString("phone"));
			customerModel.setAge(rs.getInt("age"));
			customerModel.setAddress(rs.getString("address"));
			customerModel.setCoupon(rs.getString("coupon"));
			}
		} catch (final SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return customerModel;
		
	}	
//	public int deleteProgram(String pID) throws SQLException{
//		int count=0;
//		String sql = "delete from programs where id = ?";
//		PreparedStatement pst = conn.prepareStatement(sql);
//	    pst.setString(1, pID);
//		pst.execute();
//		this.refresh();
//		return count;
//	}
//	public int updateProgram(DriverModel program) throws Exception{
//		int count=0;
//			 String query = "update Programs set name=?, seats=?, semester=? where id=?";
//		     PreparedStatement preparedStmt = conn.prepareStatement(query);
//		     preparedStmt.setString(1, program.getpName());
//		     preparedStmt.setString(2, program.getpSeats());
//		     preparedStmt.setString(3, program.getpSemesters());
//		     preparedStmt.setString(4, program.getpID());
//		     preparedStmt.execute();
//		     System.out.print(query);
//		     this.refresh();
//		     return count;
//			
//		}
	
	public List<RideModel> getCustomerRides(int id) throws SQLException{
		 List<RideModel> rides = new ArrayList<>();
		RideModel ride=null;
		final String sql = "Select * From tbl_cab_rides where CustomerID = "+id;
		stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		rs = stm.executeQuery(sql);
		while(rs.next()) {
			ride=new RideModel();
			ride.setId(rs.getInt("id"));
			ride.setSource(rs.getString("source"));
			ride.setDestination(rs.getString("destination"));
			ride.setPrice(rs.getDouble("price"));
			ride.setStartTime(rs.getString("starttime"));
			ride.setTravelTime(rs.getInt("traveltime"));
			ride.setDriverId(rs.getInt("driverid"));
			ride.setCompleted(rs.getInt("completed"));
			rides.add(ride);
		}

		return rides;
			
	}
	public List<RideModel> getDriverRides(int id) throws SQLException{
		 List<RideModel> rides = new ArrayList<>();
		RideModel ride=null;
		final String sql = "Select * From tbl_cab_rides where DRIVERID = "+id;
		stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		rs = stm.executeQuery(sql);
		while(rs.next()) {
			ride=new RideModel();
			ride.setId(rs.getInt("id"));
			ride.setSource(rs.getString("source"));
			ride.setDestination(rs.getString("destination"));
			ride.setPrice(rs.getDouble("price"));
			ride.setStartTime(rs.getString("starttime"));
			ride.setTravelTime(rs.getInt("traveltime"));
			ride.setDriverId(rs.getInt("driverid"));
			ride.setCompleted(rs.getInt("completed"));
			rides.add(ride);
		}

		return rides;
			
	}
	
}

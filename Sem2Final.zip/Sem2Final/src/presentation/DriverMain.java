package presentation;

import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import business.DriverModel;
import business.RideModel;
import data.DBAccess;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.SpringLayout;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.event.KeyEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DriverMain extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2018077826786410343L;
	private JPanel contentPane;
	DBAccess dbAccess = null;
	DriverModel driverModel = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DriverMain frame = new DriverMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public DriverMain(){
		init();
	}	/**
	 * Create the frame.
	 */
	public DriverMain(DriverModel driverModel) {
		this.driverModel=driverModel;
System.out.println("Driver ID in : "+driverModel.getId());
		init();
	}
	public void init()
	{
		setTitle("Driver ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 848, 468);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnFile = new JMenu("File");
		mnFile.setMnemonic('F');
		mnFile.setMnemonic(KeyEvent.VK_F);
		menuBar.add(mnFile);

		JMenuItem mntmHome = new JMenuItem("Main Page");
		mntmHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				CabManagement cm = new CabManagement();
				cm.setVisible(true);
			}
		});
		mntmHome.setMnemonic('M');
		mntmHome.setMnemonic(KeyEvent.VK_M);
		mnFile.add(mntmHome);

		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		mntmExit.setMnemonic('E');
		mntmExit.setMnemonic(KeyEvent.VK_E);
		mnFile.add(mntmExit);

		JMenu mnAbout = new JMenu("About");
		mnAbout.setMnemonic('A');
		mnAbout.setMnemonic(KeyEvent.VK_A);
		menuBar.add(mnAbout);

		JMenuItem mntmVersion = new JMenuItem("Version");
		mntmVersion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Application Version is 2020.01 ");
			}
		});
		mntmVersion.setMnemonic('V');
		mntmVersion.setMnemonic(KeyEvent.VK_V);
		mnAbout.add(mntmVersion);

		JMenu mnHelp = new JMenu("Help");
		mnHelp.setMnemonic('H');
		mnHelp.setMnemonic(KeyEvent.VK_H);
		menuBar.add(mnHelp);

		JMenuItem mntmCheckForUpdate = new JMenuItem("Check for update");
		mntmCheckForUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "This is the latest version of Application");
			}
		});
		mntmCheckForUpdate.setMnemonic('U');
		mntmCheckForUpdate.setMnemonic(KeyEvent.VK_U);
		mnHelp.add(mntmCheckForUpdate);

		JMenuItem mntmDeveloperInfo = new JMenuItem("Developer Info");
		mntmDeveloperInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Developed by Vijaykumar Thakar and Karan Gajjar.");
			}
		});
		mntmDeveloperInfo.setMnemonic('D');
		mntmDeveloperInfo.setMnemonic(KeyEvent.VK_D);
		mnHelp.add(mntmDeveloperInfo);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel registerPanel = new JPanel();
		registerPanel.setLayout(new GridLayout(0, 2));
		registerPanel.setBounds(226, 48, 498, 315);
		contentPane.add(registerPanel);
		registerPanel.setVisible(false);

		JPanel ridesPanel = new JPanel();
		ridesPanel.setLayout(new GridLayout(0, 1));
		ridesPanel.setBounds(226, 48, 498, 315);
		contentPane.add(ridesPanel);
		ridesPanel.setVisible(false);
		JTextArea jTextArea = new JTextArea(12,6);
		jTextArea.setBounds(226, 48, 498, 315);
		ridesPanel.add(jTextArea);


		JButton btnRide = new JButton("Create Ride");
		btnRide.setBounds(10, 25, 124, 30);
		contentPane.add(btnRide);

		btnRide.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				registerPanel.setVisible(true);
				System.out.println("create ride");

			}
		});

		JButton btnNotification = new JButton("Notification");
		btnNotification.setBounds(10, 82, 124, 30);
		contentPane.add(btnNotification);

		JButton btnRecent = new JButton("All Rides");
		btnRecent.setBounds(10, 143, 124, 30);
		contentPane.add(btnRecent);
		btnRecent.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					jTextArea.setText("");
					ridesPanel.setVisible(true);
					registerPanel.setVisible(false);
					dbAccess = new DBAccess();
					System.out.println("Driver ID "+driverModel.getId());
					List<RideModel> list= dbAccess.getDriverRides(driverModel.getId());
					jTextArea.append("ID       Source        Destination      Time        Cost  ");
					for (RideModel rideModel : list) {
						jTextArea.append("\n"+ rideModel.getId());
						jTextArea.append("      "+ rideModel.getSource());
						jTextArea.append("      "+ rideModel.getDestination());
						jTextArea.append("      "+ rideModel.getStartTime());
						jTextArea.append("      "+ rideModel.getPrice());
						
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});

		JButton btnFeedback = new JButton("Feedback");
		btnFeedback.setBounds(10, 201, 124, 30);
		contentPane.add(btnFeedback);

		JButton btnIssues = new JButton("Issues");
		btnIssues.setBounds(10, 259, 124, 30);
		contentPane.add(btnIssues);

		JButton btnHelp = new JButton("Help");
		btnHelp.setBounds(10, 316, 124, 30);
		contentPane.add(btnHelp);

		JButton btnExit = new JButton("Exit");
		btnExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		btnExit.setBounds(10, 367, 124, 30);
		contentPane.add(btnExit);

		JLabel lblCreate = new JLabel("Create your Ride below : ");
		JLabel lblSource = new JLabel("Source : ");
		JLabel lblDestination = new JLabel("Destination : ");
		JLabel lblCost = new JLabel("Cost : ");
		JLabel lblStartTime = new JLabel("Start Time : ");
		JLabel lblTotalTime = new JLabel("Total Time : ");

		JTextField txtSource = new JTextField(15);
		JTextField txtDestination = new JTextField(15);
		JTextField txtCost = new JTextField(15);
		JTextField txtStartTime = new JTextField("mm/dd/yyyy", 15);
		JTextField txtTotalTime = new JTextField(15);

		// registerPanel.add(lblCreate);
		registerPanel.add(lblSource);
		registerPanel.add(txtSource);

		registerPanel.add(lblDestination);
		registerPanel.add(txtDestination);

		registerPanel.add(lblCost);
		registerPanel.add(txtCost);

		registerPanel.add(lblStartTime);
		registerPanel.add(txtStartTime);
		registerPanel.add(lblTotalTime);
		registerPanel.add(txtTotalTime);

		JButton btnSubmit = new JButton("Submit");
		registerPanel.add(btnSubmit);
		btnSubmit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					dbAccess = new DBAccess();
					String source = txtSource.getText().toString();
					Double cost = Double.parseDouble(txtCost.getText().toString());
					String destination = txtDestination.getText().toString();
					int driverId = driverModel.getId();
					int completed = 0;
						String startTime=txtStartTime.getText().toString();
		
					int traveTime = Integer.parseInt(txtTotalTime.getText().toString());
					dbAccess.createRide(new RideModel(driverId,source,destination,cost,startTime,traveTime,driverId,completed));
						JOptionPane.showMessageDialog(null, "Ride created successfully");
					txtSource.setText("");
					 txtSource.setText("");
					 txtDestination.setText("");
					 txtCost.setText("");
					 txtStartTime.setText("");
					 txtTotalTime.setText("");
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "Error Try Again Later."+e1.getMessage());

				}
				
			}
		});
		
	
	}	
		
}

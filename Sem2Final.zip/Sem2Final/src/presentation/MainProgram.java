package presentation;

public class MainProgram {

	public static void main(String[] args) {
		
		CabManagement frame = new CabManagement();
		frame.setVisible(true);

	}

}
